def main():
    print("Hello from repl-nix-workspace!")


if __name__ == "__main__":
    main()
